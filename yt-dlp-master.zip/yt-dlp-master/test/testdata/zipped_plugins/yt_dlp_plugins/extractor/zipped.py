from yt_dlp.extractor.common import InfoExtractor


class ZippedPluginIE(InfoExtractor):
    pass
